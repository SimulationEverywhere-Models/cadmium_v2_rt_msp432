/**
 * James Grieder
 * ARSLab - Carleton University
 * August 2023
 *
 * An atomic DEVS model for the Embedded Cadmium IO_Testing_Analog example on the
 * MSP432P401R Microcontroller used with the Educational Boosterpack MK II.  This
 * example demonstrates how to use a variety of inputs and outputs in Embedded Cadmium.
 *
 * analogIOController controls the computation of various I/O modes, listed below:
 *
 * Mode 0:  Input: microphone | Output: buzzer
 *          Creating input noise to the microphone above a certain threshold causes the
 *          buzzer to generate a sound.
 *
 * Mode 1:  Input: joystick XY | Output: RB LED pwm
 *          Moving the joystick on its X and Y axes will change the colour displayed on
 *          the Boosterpacks RGB (the green LED is not used in this example).
 *
 * Mode 2:  Input: joystick btn | Output: G LED digital
 *          Clicking the joystick's button will cause the MSP432's green LED to toggle
 *          on and off.
 *
 * Mode 3:  Input: accelerometer | Output: RGB LED pwm
 *          Physically moving the MSP432 will cause the Boosterpack's RGB LED to change
 *          colour, depending on the magnitude of acceleration in the X, Y and Z axes.
 *
 * Mode 4:  Input: gator hole | Output: buzzer
 *          Closing the circuit, by touching both metal plates at the top of the
 *          Boosterpack will cause the buzzer to generate a sound.
 *
 * Mode 5:  Input: lower button | Output: LCD screen
 *          Pressing the lower button on the Boosterpack will cause the LCD functions
 *          to be invoked in the following order:
 *
 *          BSP_LCD_FillRect()
 *          BSP_LCD_DrawPixel()
 *          BSP_LCD_DrawFastVLine()
 *          BSP_LCD_DrawFastHLine()
 *          BSP_LCD_DrawString()
 *
 *          Please see below for the full function calls, including parameters.
 *
 *
 * The top button on the Boosterpack is used to cycle between input/output modes, which
 * are then displayed on the lcd screen.  The user can use the specified input to trigger
 * an output on the hardware.
 */

#ifndef __ANALOG_IO_CONTROLLER_HPP__
#define __ANALOG_IO_CONTROLLER_HPP__

// This is an atomic model, meaning it has its' own internal logic/computation
// So, it is necessary to include atomic.hpp
#include <modeling/devs/atomic.hpp>

#if !defined NO_LOGGING || !defined EMBED
#include <iostream>
#endif

namespace cadmium::analogIOSystem {
    // A class to represent the state of this specific model
    // All atomic models will have their own state
    struct AnalogIOControllerState {

        // sigma is a mandatory variable for atomic models, used to advance the time of the simulation
        double sigma;

        // Declare model-specific variables

        int mode;       // The mode of the analogIOSystem - determines which input and output are currently used
        int lcdMode;    // Used for mode 5 (LCD Output), to determine the next output function

        std::string currentMode;    // These strings are used to display program info on the screen for all modes
        std::string inputMode;
        std::string outputMode;

        std::string nextLCDFunction; // Used to output for mode 5 (LCD Output)

        // Digital outputs for the MSP432 RGB
        bool redOn;
        bool greenOn;

        // Duty cycles for PWMOutputs
        int buzzerDuty;
        int redDuty;
        int greenDuty;
        int blueDuty;


        // Set the default values for the state constructor for this specific model
        AnalogIOControllerState(): sigma(0), mode(0), lcdMode(0), redOn(false), greenOn(false), buzzerDuty(0), redDuty(0), greenDuty(0), blueDuty(0) {}
    };

#if !defined NO_LOGGING || !defined EMBED 
    /**
     * This function is used to output the current state of the model to the .csv output
     * file after each internal transition.  This is used to verify the accuracy of the
     * simulation.
     *
     * In this model, each of the relevant I/O states are printed to the .csv file.
     * Due to the model's number of inputs/outputs, the resulting file is cumbersome,
     * but it has been used to verify the accuracy of the program.
     *
     * @param out output stream.
     * @param s state to be represented in the output stream.
     * @return output stream with state variables inserted.
     */
    std::ostream& operator<<(std::ostream &out, const AnalogIOControllerState& state) {
        out << ", mode: " << state.mode << ", buzzerDuty: " << state.buzzerDuty << ", redDuty: " << state.redDuty << ", greenDuty: " << state.greenDuty << ", blueDuty: " << state.blueDuty << ", greenOn: " << state.greenOn << ", inputMode: " << state.inputMode << ", outputMode: " << state.outputMode;
        return out;
    }
#endif

    // Atomic model of AnalogIOController
    class AnalogIOController : public Atomic<AnalogIOControllerState> {
    private:

    public:

        // Declare ports for the model

        // Digital input ports
        Port<bool> inModeToggle;
        Port<bool> inLowerButton;
        Port<bool> inGatorHole;

        // Other input ports
        Port<int> inMicrophone;
        Port<int> inJoystickX;
        Port<int> inJoystickY;
        Port<bool> inJoystickSelect;
        Port<int> inAccelerometerX;
        Port<int> inAccelerometerY;
        Port<int> inAccelerometerZ;

        // Digital output ports
        Port<bool> outDigitalRed;
        Port<bool> outDigitalGreen;

        // LCD Output ports
        Port<std::string> lcdMode;
        Port<std::string> lcdInputText;
        Port<std::string> lcdOutputText;
        Port<std::string> lcdOut;

        // PWMOutput ports
        Port<int> outBuzzer;
        Port<int> outPWMRed;
        Port<int> outPWMGreen;
        Port<int> outPWMBlue;


        // Declare variables for the model's behaviour
        int numModes = 6;
        double pollingRate;

        /**
         * Constructor function for this atomic model, and its respective state object.
         *
         * For this model, both an analogIOController object and an analogIOControllerState object
         * are created, using the same id.
         *
         * @param id ID of the new analogIOController model object, will be used to identify results on the output file
         */
        AnalogIOController(const std::string& id): Atomic<AnalogIOControllerState>(id, AnalogIOControllerState()) {

            // Initialize ports for the model

            // Digital inputs
            inModeToggle = addInPort<bool>("inModeToggle");
            inLowerButton = addInPort<bool>("inLowerButton");
            inGatorHole = addInPort<bool>("inGatorHole");

            // Other inputs
            inMicrophone = addInPort<int>("inMicrophone");
            inJoystickX = addInPort<int>("inJoystickX");
            inJoystickY = addInPort<int>("inJoystickY");
            inJoystickSelect = addInPort<bool>("inJoystickSelect");
            inAccelerometerX = addInPort<int>("inAccelerometerX");
            inAccelerometerY = addInPort<int>("inAccelerometerY");
            inAccelerometerZ = addInPort<int>("inAccelerometerZ");

            // Digital outputs
            outDigitalRed = addOutPort<bool>("out");
            outDigitalGreen = addOutPort<bool>("outDigitalGreen");

            // LCD Outputs
            lcdMode = addOutPort<std::string>("lcdMode");
            lcdInputText = addOutPort<std::string>("lcdInputText");
            lcdOutputText = addOutPort<std::string>("lcdOutputText");
            lcdOut = addOutPort<std::string>("lcdOut");

            // PWMOutputs
            outBuzzer = addOutPort<int>("outBuzzer");
            outPWMRed = addOutPort<int>("outPWMRed");
            outPWMGreen = addOutPort<int>("outPWMGreen");
            outPWMBlue = addOutPort<int>("outPWMBlue");


            // Initialize variables for the model's behaviour
            pollingRate = 0.1;

            // Set a value for sigma (so it is not 0), this determines how often the
            // internal transition occurs
            state.sigma = pollingRate;


            // Below we set a string for each of our string variables, and send it to the
            // corresponding output port.  This displays the initial strings on the LCD screen
            // upon debugging.
            state.currentMode = "BSP_LCD_DrawString(0,0,mode: " + std::to_string(state.mode) + ",LCD_WHITE)";
            lcdMode->addMessage(state.currentMode);
            state.inputMode = "BSP_LCD_DrawString(0,3,in: microphone,LCD_WHITE)";
            lcdInputText->addMessage(state.inputMode);
            state.outputMode = "BSP_LCD_DrawString(0,6,out: buzzer,LCD_WHITE)";
            lcdOutputText->addMessage(state.outputMode);

            // Below we set a string for nextLCDFunction - while this is not used for the
            // beginning of the program, it is required to have a string initialized to
            // avoid errors.
            state.nextLCDFunction = "BSP_LCD_DrawPixel(126,126,LCD_BLACK)";

        }

        /**
         * The transition function is invoked each time the value of
         * state.sigma reaches 0.
         *
         * In this model, the value of state.redOn is toggled.
         *
         * @param state reference to the current state of the model.
         */
        void internalTransition(AnalogIOControllerState& state) const override {

            state.redOn = !state.redOn;

        }

        /**
         * The external transition function is invoked each time external data
         * is sent to an input port for this model.
         *
         * In this model, the value of state.mode is incremented each time the
         * top button connected to the "inModeToggle" port is pressed.  String
         * variables are updated to be printed on the LCD screen, and all other
         * state variables are reset.
         *
         * Depending on the current mode, the corresponding input ports are polled
         * and state variables are either updated, or discarded.
         *
         * @param state reference to the current model state.
         * @param e time elapsed since the last state transition function was triggered.
         */
        void externalTransition(AnalogIOControllerState& state, double e) const override {

            // First check if there are un-handled inputs for each port
            if(!inModeToggle->empty()){

                // The variable x is created to handle the external input values in sequence.
                // The getBag() function is used to get the next input value.
                for( const auto x : inModeToggle->getBag()){
                    if (x==0) {
                        state.mode++;
                        state.mode %= numModes;

                        state.currentMode = "BSP_LCD_DrawString(0,0,mode: " + std::to_string(state.mode) + ",LCD_WHITE)";

                        // reset states when we switch modes
                        state.buzzerDuty = 0;
                        state.redDuty = 0;
                        state.greenDuty = 0;
                        state.blueDuty = 0;
                        state.greenOn = false;

                        switch (state.mode) {

                        case 0:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: microphone   ,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: buzzer pwm    ,LCD_WHITE)";
                            break;

                        case 1:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: joystick XY  ,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: RB LED pwm    ,LCD_WHITE)";
                            break;

                        case 2:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: joystick btn ,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: G LED digital,LCD_WHITE)";
                            break;

                        case 3:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: accelerometer,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: RGB LED pwm  ,LCD_WHITE)";
                            break;

                        case 4:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: gator hole   ,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: buzzer       ,LCD_WHITE)";
                            break;

                        case 5:
                            state.inputMode = "BSP_LCD_DrawString(0,3,in: lower button ,LCD_WHITE)";
                            state.outputMode = "BSP_LCD_DrawString(0,6,out: LCD screen   ,LCD_WHITE)";
                            break;
                        }
                    }
                }
            }

            if(!inMicrophone->empty()) {
                for ( const auto x : inMicrophone->getBag()) {
                    switch (state.mode) {
                    case 0:
                        if (x > 550) {
                            state.buzzerDuty = 25;
                        } else {
                            state.buzzerDuty = 0;
                        }
                    }
                }
            }


            if(!inJoystickX->empty()) {
                for ( const auto x : inJoystickX->getBag()) {
                    switch (state.mode) {
                    case 1:
                        state.redDuty = x;
                    }
                }
            }

            if(!inJoystickY->empty()) {
                for ( const auto y : inJoystickY->getBag()) {
                    switch (state.mode) {
                    case 1:
                        state.blueDuty = y;
                    }
                }
            }

            if(!inJoystickSelect->empty()) {
                for ( const auto select : inJoystickSelect->getBag()) {
                    switch (state.mode) {
                    case 2:
                        if (select) {
                            state.greenOn = !state.greenOn;
                        }
                    }
                }
            }

            if(!inAccelerometerX->empty()) {
                for ( const auto x : inAccelerometerX->getBag()) {
                    switch (state.mode) {
                    case 3:
                        state.redDuty = x;
                    }
                }
            }

            if(!inAccelerometerY->empty()) {
                for ( const auto y : inAccelerometerY->getBag()) {
                    switch (state.mode) {
                    case 3:
                        state.greenDuty = y;
                    }
                }
            }

            if(!inAccelerometerZ->empty()) {
                for ( const auto z : inAccelerometerZ->getBag()) {
                    switch (state.mode) {
                    case 3:
                        state.blueDuty = z;
                    }
                }
            }


            if(!inGatorHole->empty()) {
                for ( const auto g : inGatorHole->getBag()) {
                    switch (state.mode) {
                    case 4:
                        if (g) {
                            state.buzzerDuty = 20;
                        } else {
                            state.buzzerDuty = 0;
                        }
                    }
                }
            }

            if (!inLowerButton->empty()) {
                for ( const auto l : inLowerButton->getBag()) {
                    switch (state.mode) {
                    case 5:
                        if (l == 0) {
                            switch (state.lcdMode) { // Note that all odd numbered states reverse the effect of the previous state
                            case 0:
                                state.nextLCDFunction = "BSP_LCD_FillRect(60,90,10,15,LCD_GREEN)";
                                break;

                            case 1:
                                state.nextLCDFunction = "BSP_LCD_FillRect(60,90,10,15,LCD_BLACK)";
                                break;

                            case 2:
                                state.nextLCDFunction = "BSP_LCD_DrawPixel(70,90,LCD_CYAN)";
                                break;

                            case 3:
                                state.nextLCDFunction = "BSP_LCD_DrawPixel(70,90,LCD_BLACK)";
                                break;

                            case 4:
                                state.nextLCDFunction = "BSP_LCD_DrawFastVLine(30,90,30,LCD_RED)";
                                break;

                            case 5:
                                state.nextLCDFunction = "BSP_LCD_DrawFastVLine(30,90,30,LCD_BLACK)";
                                break;

                            case 6:
                                state.nextLCDFunction = "BSP_LCD_DrawFastHLine(5,110,100,0xFD50)";
                                break;

                            case 7:
                                state.nextLCDFunction = "BSP_LCD_DrawFastHLine(5,110,100,0x0000)";
                                break;

                            case 8:
                                state.nextLCDFunction = "BSP_LCD_DrawString(3,9,test string! :],LCD_YELLOW)";
                                break;

                            case 9:
                                state.nextLCDFunction = "BSP_LCD_DrawString(3,9,               ,LCD_YELLOW)";
                                break;

                            }
                            state.lcdMode++;
                            state.lcdMode %= 10;
                        }
                    }
                }
            }
        }

        /**
         * This function outputs any desired state values to their associated ports.
         *
         * In this model, the value of each state variable is sent via its respective
         * output port.  Once these values reach their respective I/O model, the
         * hardware will be updated accordingly for any changes to the state variables.
         *
         * @param state reference to the current model state.
         */
        void output(const AnalogIOControllerState& state) const override {

            // DigitalOutput ports
            outDigitalRed->addMessage(state.redOn);
            outDigitalGreen->addMessage(state.greenOn);

            // PWMOutput ports
            outBuzzer->addMessage(state.buzzerDuty);
            outPWMRed->addMessage(state.redDuty);
            outPWMGreen->addMessage(state.greenDuty);
            outPWMBlue->addMessage(state.blueDuty);

            // LCDOutput ports
            lcdMode->addMessage(state.currentMode);
            lcdInputText->addMessage(state.inputMode);
            lcdOutputText->addMessage(state.outputMode);
            lcdOut->addMessage(state.nextLCDFunction);
        }

        /**
         * Returns the value of state.sigma for this model.
         *
         * This function is the same for all models, and does not need to be changed.
         *
         * @param state reference to the current model state.
         * @return the sigma value.
         */
        [[nodiscard]] double timeAdvance(const AnalogIOControllerState& state) const override {

            return state.sigma;

        }
    };
} // namespace cadmium::analogIOSystem

#endif // __ANALOG_IO_CONTROLLER_HPP__
