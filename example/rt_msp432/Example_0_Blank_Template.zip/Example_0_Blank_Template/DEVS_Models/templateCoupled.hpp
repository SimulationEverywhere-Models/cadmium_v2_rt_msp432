#ifndef __TEMPLATECOUPLED_HPP__
#define __TEMPLATECOUPLED_HPP__

// This is a coupled model, meaning it has no internal computation, and is
// used to connect atomic models.  So, it is necessary to include coupled.hpp
#include <modeling/devs/coupled.hpp>

#ifdef EMBED
    #include "../../IO_Models/accelerometerInput.hpp"
    #include "../../IO_Models/digitalInput.hpp"
    #include "../../IO_Models/digitalOutput.hpp"
    #include "../../IO_Models/joystickInput.hpp"
    #include "../../IO_Models/lcdOutput.hpp"
    #include "../../IO_Models/lightSensorInput.hpp"
    #include "../../IO_Models/microphoneInput.hpp"
    #include "../../IO_Models/pwmOutput.hpp"
    #include "../../IO_Models/temperatureSensorInput.hpp"
#else
    #include <lib/iestream.hpp>
#endif

// We include any models that are directly contained within this coupled model
#include <templateAtomic.hpp>

namespace cadmium::templateCoupled {
    class TemplateCoupled : public Coupled {
        public:
        TemplateCoupled(const std::string& id): Coupled(id){

            // Declare and initialize all controller models (non-input/output)


            // Connect any non-input/output models with coupling



        #ifdef EMBED

            // Declare and initialize all embedded input/output models



            // Connect IO models with coupling to the system



        #else

            // Declare and initialize all simulated input files (these must exist in the file system before compilation)


            // Connect the input files to the rest of the simulation with coupling


        #endif
        }
    };
} // namespace cadmium::templateCoupled

#endif // __TEMPLATECOUPLED_HPP__
